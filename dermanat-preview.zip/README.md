# Dermanat Preview

Vista estática de demostración exportada del WordPress local de Laboratorios Dermanat.

- 12 páginas y 31 fichas de fórmulas.
- Catálogo con filtros y búsqueda, selección de fórmulas, cantidades y resumen para WhatsApp.
- Los formularios solo simulan el flujo: no envían ni almacenan solicitudes ni datos de contacto.
- La edición con Elementor continúa en el WordPress local, fuera de este repositorio.
- Sin bases de datos, cuentas de WordPress, archivos PHP ni credenciales.

Publicación prevista: https://dtiradop.github.io/dermanat-preview/

Configurar GitHub Pages desde la rama `main`, carpeta `/ (root)`. El sitio usa el prefijo `/dermanat-preview/`.
