(function(root,factory){if(typeof module==='object'&&module.exports)module.exports=factory();else root.DNPricing=factory();})(typeof globalThis!=='undefined'?globalThis:this,function(){
 'use strict';
 function unitPrice(product,quantity){
  if(!Number.isInteger(quantity)||quantity<500||quantity>1000000)return null;
  const tier=(product?.priceTiers||[]).find(t=>quantity>=t.min&&(t.max===null||quantity<=t.max));
  return tier&&Number.isInteger(tier.unit_price)&&tier.unit_price>=0?tier.unit_price:null;
 }
 function quote(products,items){
  let subtotal=0,pricedCount=0,unpricedCount=0;
  const lines=items.map(item=>{const product=products.get(Number(item.id));const unit=unitPrice(product,item.quantity);const total=unit===null?null:unit*item.quantity;if(total===null)unpricedCount++;else{subtotal+=total;pricedCount++;}return {...item,name:product?.name||'',unitPrice:unit,subtotal:total};});
  return {lines,subtotal,pricedCount,unpricedCount};
 }
 function money(amount){return new Intl.NumberFormat('es-CO',{style:'currency',currency:'COP',maximumFractionDigits:0}).format(amount)+' COP';}
 return {unitPrice,quote,money};
});
